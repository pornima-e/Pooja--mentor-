/**
 * OPTIONAL — only needed if you want real AI photo analysis in Food & Care.
 * Without this, the app works completely normally using manual meal entry.
 *
 * This is a Cloudflare Worker (free tier, no credit card needed to start)
 * that safely proxies requests to the Anthropic API. Your Anthropic API key
 * stays on Cloudflare's servers as a secret — it is NEVER visible in the
 * app's frontend code, so it can't be stolen from the browser.
 *
 * SETUP (about 5 minutes):
 * 1. Go to https://dash.cloudflare.com → Workers & Pages → Create → Worker.
 * 2. Replace the default code with everything below.
 * 3. Go to Settings → Variables → add a secret named ANTHROPIC_API_KEY
 *    with your key from https://console.anthropic.com (Anthropic's API is
 *    paid per request beyond any free trial credit — this step is optional).
 * 4. Deploy. Copy the worker's URL (looks like
 *    https://pooja-mentor-food.YOURNAME.workers.dev).
 * 5. In the app, open Settings (⚙️) and paste that URL into "Backend URL".
 *
 * That's it — food photo analysis will now call your worker, which calls
 * Anthropic on your behalf.
 */

export default {
  async fetch(request, env) {
    // CORS so your GitHub Pages site can call this worker
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*', // for tighter security, replace * with your site's exact URL
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    };

    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }
    if (request.method !== 'POST') {
      return new Response('Method not allowed', { status: 405, headers: corsHeaders });
    }

    try {
      const body = await request.json();
      const mode = body.mode || 'food'; // 'food' (default, backward compatible) or 'chat'

      let system, messages;

      if (mode === 'chat') {
        // Personal AI Mentor chat — Level 2 (optional). Falls back to the
        // app's local rule-based mentor automatically if this ever fails.
        const ctx = body.context || {};
        system = `You are "Pooja's Mentor" — a warm, funny, honest, sometimes strict but always supportive personal mentor and friend living inside Pooja's personal dashboard app. You know her real stats for today: ${JSON.stringify(ctx)}. Speak like a close friend/mentor, not a corporate assistant. Use warmth and light humor, occasional emoji, and vary between calling her "Pooja", "babe", "Poju" or "girl". Never be harsh or insulting. Keep replies short — 1 to 4 sentences, natural chat length, no markdown headers or bullet walls unless she explicitly asks for a plan/list. Never invent stats she didn't give you.`;
        messages = [
          ...(Array.isArray(body.history) ? body.history.map(m => ({ role: m.role === 'user' ? 'user' : 'assistant', content: m.text })) : []),
          { role: 'user', content: body.message || '' },
        ];
      } else {
        // Food photo/description analysis — original behaviour, unchanged.
        system = `You are a friendly nutrition and wellness assistant inside a personal dashboard app. Analyze the meal (from photo and/or description) for general SKIN and HAIR wellness only. You are NOT a doctor — never diagnose medical or skin/hair conditions. Respond with ONLY a raw JSON object, no markdown fences, no extra text, in exactly this shape:
{"name":"short meal name (max 6 words)","skin":0-10 integer,"hair":0-10 integer,"nutrients":["2-4 short nutrient highlight tags, e.g. High protein, Good fibre, Vitamin C"],"good":"1-2 short sentences on what's good about this meal for skin/hair","improve":"1-2 short sentences on what could be added or improved","suggestion":"1 short sentence suggesting a simple next meal or addition"}
Keep all text concise and encouraging in tone.`;
        messages = [{ role: 'user', content: body.content }];
      }

      const anthropicRes = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': env.ANTHROPIC_API_KEY,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6',
          max_tokens: mode === 'chat' ? 300 : 1000,
          system,
          messages,
        }),
      });

      const data = await anthropicRes.json();
      return new Response(JSON.stringify(data), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    } catch (err) {
      return new Response(JSON.stringify({ error: 'Request failed' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
  },
};
